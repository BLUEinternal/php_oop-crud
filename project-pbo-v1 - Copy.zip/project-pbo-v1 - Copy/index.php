<?php 
require 'functionUser.php';

require 'layout/navbar.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman user</title>
</head>
<body>

  <table border="1" cellpadding="10" cellspacing="1">
        <tr>
            <th>No.</th>
            <th>Nama Produk</th>
            <th>foto</th>
            <th>Harga</th>
            <th>Aksi</th>
        </tr>

        <?php
        
        include "koneksi.php";
        $no=1;
        $ambildata = (mysqli_query($conn, "SELECT * FROM produk"));
        while ($tampil = mysqli_fetch_array($ambildata)){
          echo"
            <tr>
              <td>$no</td>
              <td>$tampil[nama_produk]</td>
              <td>$tampil[foto]</td>
              <td>$tampil[harga]</td>
            </tr>";
            $no++;
        }
        ?>
    </table>
</body>
</html>