<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>toko makanan</title>
    <!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
    <link rel="stylesheet" href="style.css">
    <link rel="icon" type="image/x-icon" href="asset/icon/logo.jpeg">

</head>
<body>


    <nav class="navbar navbar-expand-lg bg-light">
        <div class="container">
          <a class="navbar-brand" href="#">GESJEN</a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ms-auto mb-2 me-2 mb-lg-0">
              <li class="nav-item">
                <a class="nav-link active mx-2" aria-current="page" href="#">Home</a>
              </li>
              <li class="nav-item">
                <a class="nav-link mx-2" href="#">categories</a>
              </li>
              <li class="nav-item">
                <a class="nav-link mx-2" href="#">product</a>
              </li>
              <li class="nav-item">
                <a class="nav-link mx-2" href="#">contact</a>
              </li>
             
              <li class="nav-item">
    
              </li>
            </ul>
            <form class="d-flex" >
                <button class="btn btn-primary me-1 p-3" type="submit">login</button>
              <button class="btn btn-outline-primary p-3" type="submit">register</button>
            </form>
          </div>
        </div>
    </nav>
    <main class="container mt-3">
        <div class="row d-flex justify-content-center">
            <div class="col-12">
                <div class="banner">
                    <img src="asset/food B.png" class="img-fluid" alt="" >
                </div>
            </div>
        </div>
        <!-- bootstrap5
        COL = DINAMIS NGIKUT WAFE
        COL- = STATIS PUNYA PENDIRIAN
        CONTOH COL-6 BERARTI LEY OUT SETENGAH KARENA 12/6 = 2 -->

        <!-- VERSI HP DAN LAPTOP
        COL- = VERSI HP ZAMAN OLD DAN ZAMAN NOW
        COL-MD = VERSI TAB
        COL-LG = VERSI LEPTOP
        COL-XL = VERSI DESKTOP
        COL-XXL = VERSI DESKTOP YG LEBIH BESAR -->

      <div class="row d-flex justify-content-center mt-5">
          <div class="col-12">
            <h1 class="heading ">categories</h1>
          </div>

          </div>
          <div class="row d-flex justify-content-center mt-3">
          <div class=" col-6 col-md-4 col-lg-2 col-xl-2 mb-3">
            <div class="card card-categories py-3">
              <div class="imgae-card text-center">
                <img src="asset/icon/snack.jpg" alt="snack" class="img-fluid">
              </div>
              <div class="text-card text-center mt-2  ">snack</div>
            </div>
          </div>
          <div class="col-6 col-md-4 col-lg-2 col-xl-2 mb-3">
            <div class="card card-categories py-3">
              <div class="imgae-card text-center">
                <img src="asset/icon/bread.jpg" alt="snack" class="img-fluid">
              </div>
              <div class="text-card text-center mt-2  ">roti</div>
            </div>
          </div>
          <div class="col-6 col-md-4 col-lg-2 col-xl-2 mb-3">
            <div class="card card-categories py-3">
              <div class="imgae-card text-center">
                <img src="asset/icon/drink.jpg" alt="snack" class="img-fluid">
              </div>
              <div class="text-card text-center mt-2  ">minuman</div>
            </div>
          </div>
          <div class="col-6 col-md-4 col-lg-2 col-xl-2 mb-3">
            <div class="card card-categories py-3">
              <div class="imgae-card text-center">
                <img src="asset/icon/food.jpg" alt="snack" class="img-fluid">
              </div>
              <div class="text-card text-center mt-2  ">makanan</div>
            </div>
          </div>
          <div class="col-6 col-md-4 col-lg-2 col-xl-2 mb-3">
            <div class="card card-categories py-3">
              <div class="imgae-card text-center">
                <img src="asset/icon/milk.jpg" alt="snack" class="img-fluid">
              </div>
              <div class="text-card text-center mt-2  ">susu</div>
            </div>
          </div>
         
      </div>
      <div class="row d-flex justify-content-center mt-5">
        <div class="col-12">
          <h1 class="heading"> Populer product</h1>
        </div>
      </div>
      <div class="row d-flex justify-content-center mt-3 ">
         <div class="col-lg-3 col-xl-3 col-md-6 col-12 mb-5">
            <div><img src="asset/download.jpg" alt="food" class="img-fluid roumded"></div>
            <div class="mt-2">
              <h6>bread wuenak</h6>
              <div class="harga">RP 15.000</div>
            </div>
         </div>
         <div class="col-lg-3 col-xl-3 col-md-6 col-12 mb-5">
            <div><img src="asset/download.jpg" alt="food" class="img-fluid roumded"></div>
            <div class="mt-2">
              <h6>bread wuenak</h6>
              <div class="harga">RP 15.000</div>
            </div>
         </div>
         <div class="col-lg-3 col-xl-3 col-md-6 col-12 mb-5">
            <div><img src="asset/download.jpg" alt="food" class="img-fluid roumded"></div>
            <div class="mt-2">
              <h6>bread wuenak</h6>
              <div class="harga">RP 15.000</div>
            </div>
         </div>
         <div class="col-lg-3 col-xl-3 col-md-6 col-12 mb-5">
            <div><img src="asset/download.jpg" alt="food" class="img-fluid roumded"></div>
            <div class="mt-2">
              <h6>bread wuenak</h6>
              <div class="harga">RP 15.000</div>
            </div>
         </div>
      </div>
        
    </main> 
    <footer>
      <div class="my-4 text-center">
        copyright 2022 - All Right Reserved - smk jakarta pusat 1
      </div>
    </footer>
    




    <!-- JavaScript Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>
<script src="script.js"></script>
</body> 
</html>