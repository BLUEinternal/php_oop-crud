<?php 
session_start();
require 'functions.php';

if(!isset($_SESSION["username"])){
    echo "
    <script type='text/javascript'>
        alert('Silahkan login terlebih dahulu')
        window.location = '../login/index.php';
    </script>
    ";
}

$produk = query("SELECT * FROM produk");

?>

<?php require '../layout/sidebar.php'?>

<div class="main">
    <h2>data produk</h2>

    <a href="tambah_produk.php" class="tambah">tambah produk</a>
    <table>
        <tr>
            <th>NO.</th>
            <th>NAMA PRODUK</th>
            <th>HARGA</th>
            <th>FOTO</th>
            <th>Stok</th>
            <th>Aksi</th>
        </tr>
        <?php $i = 1  ?>
        <?php foreach($produk as $data) :   ?>
            <tr>
                <th><?=$i; ?></th>
                <th><?=$data["nama_produk"]; ?></th>
                <th><?=$data["harga"]; ?></th>
                <th><img src="../foto/<?= $data["foto"] ?>" alt="" width="80px"></th>
                <th><?=$data["stock"]; ?></th>
               <td>
                <a href="edit_produk.php?id=<?=$data["id_produk"]; ?>" class="edit">edit</a>
                <a href="hapus_produk.php?id=<?=$data["id_produk"]; ?>" class="hapus" onClick="return confirm('anda yakin ingin menghapus data ini')">hapus</a>
               </td>
              
            </tr>
            <?php $i++; ?>
            <?php  endforeach; ?>

    </table>
</div>