<?php 
session_start();
require 'functions.php';

if(!isset($_SESSION["username"])){
    echo "
    <script type='text/javascript'>
        alert('Silahkan login terlebih dahulu')
        window.location = '../login/index.php';
    </script>
    ";
}

$user = query("SELECT * FROM user")

?>

<?php require '../layout/sidebar.php'?>

<div class="main">
    <h2>data user</h2>

    <a href="tambah_user.php" class="tambah">tambah user</a>
    <table>
        <tr>
            <th>NO.</th>
            <th>NAMA LENGKAP</th>
            <th>USERNAME</th>
            <th>password</th>
            <th>role</th>
            <th>AKSI</th>
        </tr>
        <?php $i = 1  ?>
        <?php foreach($user as $data) :   ?>
            <tr>
                <th><?=$i; ?></th>
                <th><?=$data["username"]; ?></th>
                <th><?=$data["password"]; ?></th>
                <th><?=$data["role"]; ?></th>
               
               <td>
                <a href="edit_user.php?id=<?=$data["id_user"]; ?>" class="edit">edit</a>
                <a href="hapus_user.php?id=<?=$data["id_user"]; ?>" class="hapus" onClick="return confirm('anda yakin ingin menghapus')">hapus</a>
               </td>
              
            </tr>
            <?php $i++; ?>
            <?php  endforeach; ?>

    </table>
</div>