<?php

require 'functions.php';

$id = $_GET["id"];

if(hapususer($id) > 0){ 
    echo "
        <script type='text/javascript'>
            alert('data berhasil di apus');
            window.location = 'user.php';
        </script>
    ";
}else{
    echo "
    <script type='text/javascript'>
        alert('data gagal di hapus');
        window.location = 'user.php';
    </script>
";
}

?>