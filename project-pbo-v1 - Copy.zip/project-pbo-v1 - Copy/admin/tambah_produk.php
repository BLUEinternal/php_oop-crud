<?php

session_start();
require 'functions.php';

if(!isset($_SESSION["username"])){
    echo "
    <script type='text/javascript'>
        alert('Silahkan login terlebih dahulu')
        window.location = '../login/index.php';
    </script>
    ";
}

if(isset($_POST["kirim"])){
    if(tambahProduk($_POST) > 0){
    echo "
        <script type='text/javascript'>
            alert('tambah produk berhasil ditambahkan');
            window.location = 'produk.php';
        </script>
    ";
}else{
    echo "
    <script type='text/javascript'>
        alert('tambah produk gagal, silahkan di cek kembali!');
        window.location = 'produk.php';
    </script>
";
}
}



?>
<?php require '../layout/sidebar.php'?>

<div class="main">
    <div class="box">
        <h3>Tambah Data produk</h3>

        <form action="" method="POST" enctype="multipart/form-data">
            <label for="nama_prouk">nama produk</label>
            <input type="text" name="nama_produk" id="nama_prouk" class="form-control">

            <label for="harga">harga produk</label>
            <input type="text" name="harga" id="harga" class="form-control">

            <label for="foto">foto</label>
            <input type="file" name="foto" id="foto" class="form-control">

            <label for="stock">stock</label>
            <input type="text" name="stock" id="stock" class="form-control">

            <label for="deskripsi">deskripsi</label>
            <textarea type="text" name="deskripsi" id="deskripsi" class="form-control" cols="30" row="7"></textarea>
          

            

            <button type="submit" name="kirim">tambah data</button>
  
        </form>
    </div>
</div>


